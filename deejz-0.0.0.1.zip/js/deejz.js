var Item = Backbone.Model.extend({
	defaults: {
		pk: null,
		model: null,
		fields: []
	}
});